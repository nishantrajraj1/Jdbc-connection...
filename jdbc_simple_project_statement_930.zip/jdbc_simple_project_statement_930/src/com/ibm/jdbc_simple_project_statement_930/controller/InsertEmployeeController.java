package com.ibm.jdbc_simple_project_statement_930.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * 
 * @author MO MASOOD ANSARI
 * jdsfjhbfkb
 * hjsagjhsdhbsd
 * hjagjhsdvjc
 *
 */

public class InsertEmployeeController {

	
	/*
	 * dsjsbjhvdbkhk
	 */
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		
		
		Connection connection=null;
		try {
			//step-1 load/register driver class from mysql-connector.jar file
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost:3306/jdbc-930";
			String user = "root";
			String pass = "root";
			
			//step-2 create connection
			connection=DriverManager.getConnection(url, user, pass);
			
			//step-3 create-statement
			
			Statement statement = connection.createStatement();
			
			System.out.println("enter emp id");
			int id  = sc.nextInt();
			System.out.println("enter emp name");
			String name = sc.next();
			sc.nextLine();
			System.out.println("enter emp email");
			String email = sc.nextLine();
			System.out.println("enter emp phone");
			long phone = sc.nextLong();
			
			//step-4 execute-query
			
			String insertQuery = "INSERT INTO employee(id,name,email,phone) values("+id+",'"+name+"','"+email+"',"+phone+")";
			
			boolean b=statement.execute(insertQuery);
			
			System.out.println(b);
			
			System.out.println("success");
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} 
	}
}
