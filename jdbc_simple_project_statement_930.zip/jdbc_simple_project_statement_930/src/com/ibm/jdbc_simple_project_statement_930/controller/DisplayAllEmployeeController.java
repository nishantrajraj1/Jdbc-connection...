package com.ibm.jdbc_simple_project_statement_930.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayAllEmployeeController {

	public static void main(String[] args) {

		Connection connection = null;
		ResultSet resultSet=null;
		try {
			// step-1 load/register driver class from mysql-connector.jar file
			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/jdbc-930";
			String user = "root";
			String pass = "root";

			// step-2 create connection
			connection = DriverManager.getConnection(url, user, pass);

			// step-3 create-statement

			Statement statement = connection.createStatement();

			// step-4 execute-query

			String displayQuery = "SELECT * FROM employee where id=5678";

		    resultSet = statement.executeQuery(displayQuery);
			int i=1;
			if (resultSet.next()) {
				i++;
				int id = resultSet.getInt("id");
				String name = resultSet.getString("name");
				String email = resultSet.getString("email");
				long phone = resultSet.getLong("phone");

				System.out.println("id = " + id);
				System.out.println("name = " + name);
				System.out.println("email = " + email);
				System.out.println("phone = " + phone);
			}

			System.out.println("i="+i);

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
				resultSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
