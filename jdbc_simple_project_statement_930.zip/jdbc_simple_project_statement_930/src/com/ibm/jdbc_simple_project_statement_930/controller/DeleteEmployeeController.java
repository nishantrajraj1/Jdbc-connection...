package com.ibm.jdbc_simple_project_statement_930.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteEmployeeController {

	public static void main(String[] args) {

		Connection connection = null;
		try {
			// step-1 load/register driver class from mysql-connector.jar file
			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/jdbc-930";
			String user = "root";
			String pass = "root";

			// step-2 create connection
			connection = DriverManager.getConnection(url, user, pass);

			// step-3 create-statement

			Statement statement = connection.createStatement();

			// step-4 execute-query

			String deleteQuery = "delete from employee where id=380";

			int a = statement.executeUpdate(deleteQuery);

			if(a==1) {
				System.out.println("deleted!!!!");
			}else {
				System.out.println("not deleted given id is not present in table!!!!!");
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
